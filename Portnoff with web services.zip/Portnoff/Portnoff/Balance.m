//
//  Balance.m
//  Portnoff
//
//  Created by Yike Xue on 7/13/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "Balance.h"
#import "File.h"


@implementation Balance

@dynamic year;
@dynamic value;
@dynamic property;

@end
