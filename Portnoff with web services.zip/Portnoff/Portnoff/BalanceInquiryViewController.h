//
//  BalanceInquiryViewController.h
//  Portnoff
//
//  Created by Yike Xue on 7/13/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CaptchaView.h"

@interface BalanceInquiryViewController : UIViewController <UITextFieldDelegate, NSXMLParserDelegate>
@property (weak, nonatomic) IBOutlet UITextField *parcelNumber;
@property (weak, nonatomic) IBOutlet UITextField *fileNumber;
@property (weak, nonatomic) IBOutlet UITextField *captchaInput;

@property (weak, nonatomic) IBOutlet UIView *captcha;

- (IBAction)pressedSearch:(id)sender;
- (IBAction)didEndOnExit:(id)sender;

@end
