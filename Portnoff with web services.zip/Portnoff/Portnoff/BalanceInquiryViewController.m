//
//  BalanceInquiryViewController.m
//  Portnoff
//
//  Created by Yike Xue on 7/13/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "BalanceInquiryViewController.h"
#import "ShowBalanceDetailViewController.h"
#import "AppDelegate.h"
#import "Tax.h"
#import "File.h"
#import "Property.h"

@interface BalanceInquiryViewController (){
    CaptchaView *_captchaView;
    NSSet *balSet;
    NSString *addr;
    NSString *holder;
    NSManagedObjectContext* managedObjectContext;
    NSFetchedResultsController *fetchedResultsController;

    NSMutableData *webData;
    NSMutableString *soapResults;
    NSXMLParser *xmlParser;
    BOOL recordResults;

    BOOL noteYear;
    BOOL noteValue;
    Balance *curB;
}

@end

@implementation BalanceInquiryViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    _captchaView = [[CaptchaView alloc] initWithFrame:CGRectMake(0, 0, 150, 40)];
    self.parcelNumber.delegate = self;
    self.fileNumber.delegate = self;
    self.captchaInput.delegate = self;
    [self.captcha addSubview:_captchaView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

//In order to prevent the keyboard blocking the input boxes
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self animateTextField: textField up: YES];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self animateTextField: textField up: NO];
}
//move the view up
- (void) animateTextField: (UITextField *) textField up: (BOOL) up
{
    //move up 0.3*view.height
    const int movementDistance = self.view.frame.size.height*0.3; // tweak as needed

    int movement = (up ? -movementDistance : movementDistance);

    [UIView beginAnimations: @"Animation" context: nil];

    [UIView setAnimationBeginsFromCurrentState: YES];

    [UIView setAnimationDuration: 0.20];

    if(self.view.frame.origin.y <= 0){
        self.view.frame = CGRectOffset(self.view.frame, 0, movement);
        
        [UIView commitAnimations];
    }
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (IBAction)pressedSearch:(id)sender {
    //****************************************************************************
    //Just for simple web services test, only implement the balanceSearch function
    //Set default address and holder name
    addr = @"101 Test Road, Wayne, PA 19087";
    holder = @"Test Holder";
    
    
    if ([self.captchaInput.text isEqualToString:_captchaView.changeString]) {
//        [self coredata];
//        [self balanceSOAP];
        [self balanceHTTPRequest];
    }
    else
    {
        CAKeyframeAnimation *anim = [CAKeyframeAnimation animationWithKeyPath:@"transform.translation.x"];
        anim.repeatCount = 1;
        anim.values = @[@-20, @20, @-20];
        [_captchaView.layer addAnimation:anim forKey:nil];
        UIAlertView *alview = [[UIAlertView alloc] initWithTitle:@"Wrong Captcha!" message:@"The captcha is invalid! Please try again." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alview show];
        [_captchaView changeCaptcha];
        [_captchaView setNeedsDisplay];
        self.captchaInput.text = @"";
    }
    
}

-(void)coredata{
    AppDelegate *appDelegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    managedObjectContext = appDelegate.managedObjectContext;
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription
                                   entityForName:@"Tax" inManagedObjectContext:managedObjectContext];
    [fetchRequest setEntity:entity];
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"parcelNumber"ascending:YES];
    [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    
    NSPredicate * predicate;
    predicate = [NSPredicate predicateWithFormat:@"parcelNumber == %@", self.parcelNumber.text];
    [fetchRequest setPredicate: predicate];
    [fetchRequest setFetchLimit:1];
    
    NSError *error;
    NSArray *fetchedObjects = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
    if (error) {
        NSLog(@"Error : %@\n", [error localizedDescription]);
    }
    
    if(fetchedObjects == nil || [fetchedObjects count] < 1){
        UIAlertView *alview = [[UIAlertView alloc] initWithTitle:@"No searching result!" message:@"The parcel number is invalid! Please try again." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alview show];
    }else{
        Tax *result = [fetchedObjects objectAtIndex:0];
        addr = result.property.address;
        NSFetchRequest *fetchRequest2 = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity2 = [NSEntityDescription
                                        entityForName:@"File" inManagedObjectContext:managedObjectContext];
        [fetchRequest2 setEntity:entity2];
        NSError *error2;
        NSPredicate * predicate2;
        predicate2 = [NSPredicate predicateWithFormat:@"fileNumber == %@", self.fileNumber.text];
        [fetchRequest2 setPredicate: predicate2];
        
        NSArray *fetchedObjects2 = [managedObjectContext executeFetchRequest:fetchRequest2 error:&error2];
        
        if(fetchedObjects2 == nil || [fetchedObjects2 count] < 1){
            UIAlertView *alview = [[UIAlertView alloc] initWithTitle:@"No searching result!" message:@"The file number is invalid! Please try again." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alview show];
        }else{
            File *result2 = fetchedObjects2[0];
            holder = result2.hoderName;
            NSSet *bals = result2.balances;
            //                NSFetchRequest *fetchRequest3 = [[NSFetchRequest alloc] init];
            //                NSEntityDescription *entity3 = [NSEntityDescription
            //                                                entityForName:@"Balance" inManagedObjectContext:managedObjectContext];
            //                [fetchRequest3 setEntity:entity3];
            //                NSError *error3;
            //                NSPredicate * predicate3;
            //                predicate3 = [NSPredicate predicateWithFormat:@"ANY property.parcel == %@", self.parcelNumber.text];
            //                [fetchRequest3 setPredicate: predicate3];
            //
            //                NSArray *fetchedObjects3 = [managedObjectContext executeFetchRequest:fetchRequest3 error:&error3];
            //
            //                if(fetchedObjects3 != nil && [fetchedObjects2 count] > 0){
            //                    Balance *result3 = fetchedObjects3[0];
            //                    bal = result3.value;
            balSet = bals;
            [self.parcelNumber resignFirstResponder];
            [self.fileNumber resignFirstResponder];
            [self.captchaInput resignFirstResponder];
            [_captchaView changeCaptcha];
            [_captchaView setNeedsDisplay];
            [self performSegueWithIdentifier:@"showDetail" sender:self];
        }
    }
}

-(void)balanceHTTPRequest{
    NSURL*url=[NSURL URLWithString:[NSString stringWithFormat:@"http://52.10.50.6:8080/servlet/database?fileNum=%@", self.fileNumber.text]];
    NSMutableURLRequest*urlRequest=[NSMutableURLRequest requestWithURL:url];
    
    [urlRequest addValue: @"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    //    [urlRequest addValue: @"database" forHTTPHeaderField:@"SOAPAction"];
    //    [urlRequest addValue: msgLength forHTTPHeaderField:@"Content-Length"];
    
    [urlRequest setHTTPMethod:@"GET"];
    //    [urlRequest setHTTPBody:[soapMessage dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLResponse *response;
    NSError*error=nil;
    NSLog(@"URL: %@",url);
    
    //receive return data
    NSData *responseData=[NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&response error:&error];
    NSMutableString *result=[[NSMutableString alloc]initWithData:responseData encoding:NSUTF8StringEncoding ];
    NSLog(@"return string is============>>\n%@",result);
    
    NSRange rangY = [result rangeOfString:@"Year"];
    NSRange rangV = [result rangeOfString:@"Value"];
    //Get return data
    if([result rangeOfString:@"Year"].length > 0 && [result rangeOfString:@"Value"].length > 0){
        
        NSRange rang = NSMakeRange(rangY.location+5, 4);
        NSString *y = [result substringWithRange:rang];
        rang = NSMakeRange(rangV.location+6, 10);
        NSString *v = [result substringFromIndex:rangV.location+6];
        NSRange valEnd = [v rangeOfString:@"br"];
        NSString *valOnly = [v substringWithRange:NSMakeRange(0, valEnd.location)];
        
        NSDictionary *ba = [[NSDictionary alloc] initWithObjectsAndKeys:y,@"year",[NSNumber numberWithFloat:[valOnly floatValue]],@"value", nil];
        NSSet *bals = [[NSSet alloc] initWithObjects:ba, nil];
        
        balSet = bals;
        [self.parcelNumber resignFirstResponder];
        [self.fileNumber resignFirstResponder];
        [self.captchaInput resignFirstResponder];
        [_captchaView changeCaptcha];
        [_captchaView setNeedsDisplay];
        [self performSegueWithIdentifier:@"showDetail" sender:self];
    }else{
        UIAlertView *alview = [[UIAlertView alloc] initWithTitle:@"No searching result!" message:@"The file number is invalid! Please try again." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alview show];
    }
}
#pragma mark -
#pragma mark webService Data

-(void)balanceSOAP{
    recordResults = NO;
//    NSString *soapMessage = [NSString stringWithFormat:
//                             @"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
//                             "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" soap:encodingStyle=\"http://www.w3.org/2001/12/soap-encoding\">\n"
//                             "<soap:Body>\n"
//                             "<getBalance xmlns=\"http://localhost:8080/PortnoffWebService\">\n"
//                             "<fileNum>1"
//                             "</fileNum>"
//                             "</getBalance>\n"
//                             "</soap:Body>\n"
//                             "</soap:Envelope>\n"
//                             ];

//    NSString*soapMessage=[NSString stringWithFormat:@"{\"fileNum\":\"%@\", \"parcelNum\":\"%@\"}",self.fileNumber.text,self.parcelNumber.text];
//    NSString*msgLength=[NSString stringWithFormat:@"%lu",(unsigned long)[soapMessage length]];
//    NSLog(@"The string for webservices%@",soapMessage);

    
    
    //sparse json
//    SBJsonParser *jparser=[[SBJsonParser alloc]init ];
//    NSError*JSONError=nil;
//    NSMutableDictionary*jsonDil=[jparser objectWithString:result error:&JSONError ];
//    NSLog(@"%@",[jsonDil objectForKey:@"d"]);

//    //Your server's url
//    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"http://52.10.50.6:8080/servlet/database?fileNum=%@",self.fileNumber.text]];
//    NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
//    NSString *msgLength = [NSString stringWithFormat:@"%lu", (unsigned long)[soapMessage length]];
//
//    [theRequest addValue: @"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
//    [theRequest addValue: @"http://52.10.50.6:8080/servlet/database" forHTTPHeaderField:@"SOAPAction"];
//    
//    [theRequest addValue: msgLength forHTTPHeaderField:@"Content-Length"];
//    [theRequest setHTTPMethod:@"POST"];
//    [theRequest setHTTPBody: [soapMessage dataUsingEncoding:NSUTF8StringEncoding]];
//    
//    //请求
//    NSURLConnection *theConnection = [[NSURLConnection alloc] initWithRequest:theRequest delegate:self];
//    
//    //如果连接已经建好，则初始化data
//    if( theConnection == nil)
//    {
//        NSLog(@"theConnection is NULL");
//    }
}

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    [webData setLength: 0];
    NSLog(@"%@",response.URL);
    NSLog(@"connection: didReceiveResponse:1");
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [webData appendData:data];
    NSLog(@"connection: didReceiveData:%lu", (unsigned long)[webData length]);
    
}

//no connection with the Internet
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"ERROR with theConenction");
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSLog(@"3 DONE. Received Bytes: %lu", (unsigned long)[webData length]);
    NSString *theXML = [[NSString alloc] initWithBytes: [webData mutableBytes] length:[webData length] encoding:NSUTF8StringEncoding];
    NSLog(@"%@",theXML);
    
    //reload xmlParser
    
    xmlParser = [[NSXMLParser alloc] initWithData: webData];
    [xmlParser setDelegate: self];
    [xmlParser setShouldResolveExternalEntities: YES];
    [xmlParser parse];
}

-(void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *) namespaceURI qualifiedName:(NSString *)qName
   attributes: (NSDictionary *)attributeDict
{
    NSLog(@"4 parser didStarElemen: namespaceURI: attributes:");
    
    if( [elementName isEqualToString:@"year"])
    {
//        if(!soapResults)
//        {
//            soapResults = [[NSMutableString alloc] init];
//        }
//        recordResults = YES;
        noteYear = YES;
    }else if( [elementName isEqualToString:@"value"])
    {
        noteValue = YES;
    }
    
}
-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    NSLog(@"5 parser: foundCharacters:");
    NSLog(@"recordResults:%@",string);
    if(noteYear)
    {
        [soapResults appendString: string];
        Balance *b = [[Balance alloc] init];
        b.year = string;
    }
    
}
-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    NSLog(@"6 parser: didEndElement:");
    
    if( [elementName isEqualToString:@"ns:return"])
    {
        NSLog(@"MSG");
    }
    
    if( [elementName isEqualToString:@"getOffesetUTCTimeResult"])
    {
        recordResults = FALSE;
        NSSet *bals = [[NSSet alloc] initWithObjects:@"$400 \n 2014", nil];
        balSet = bals;
        soapResults = nil;
        NSLog(@"hoursOffset result");
    }
    
}
- (void)parserDidStartDocument:(NSXMLParser *)parser{
    NSLog(@"-------------------start--------------");
}
- (void)parserDidEndDocument:(NSXMLParser *)parser{
    NSLog(@"-------------------end--------------");
}

- (IBAction)didEndOnExit:(id)sender {
    [self resignFirstResponder];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    //Get the new view controller using [segue destinationViewController].
    //Pass the selected object to the new view controller.
    if([segue.identifier isEqualToString:@"showDetail"]){
        ShowBalanceDetailViewController *destination = segue.destinationViewController;
        if ([destination respondsToSelector:@selector(setDelegate:)]) {
            [destination setValue:self forKey:@"delegate"];
        }
        if ([destination respondsToSelector:@selector(setAddress:)]) {
            
            [destination setValue:addr forKey:@"address"];
        }
        if ([destination respondsToSelector:@selector(setHolderName:)]) {
            
            [destination setValue:holder forKey:@"holderName"];
        }
        if ([destination respondsToSelector:@selector(setBalances:)]) {
            
            [destination setValue:balSet forKey:@"balances"];
        }
    }
}

@end
