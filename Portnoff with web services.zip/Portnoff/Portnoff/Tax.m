//
//  Tax.m
//  Portnoff
//
//  Created by Yike Xue on 7/13/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "Tax.h"
#import "File.h"
#import "Property.h"


@implementation Tax

@dynamic parcelNumber;
@dynamic property;
@dynamic files;

@end
