//
//  ShowBalanceDetailViewController.h
//  Portnoff
//
//  Created by Yike Xue on 7/14/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Balance.h"

@interface ShowBalanceDetailViewController : UIViewController

@property (copy, nonatomic) NSString *holderName;
@property (copy, nonatomic) NSString *address;
@property (copy, nonatomic) NSSet *balances;
@property (weak, nonatomic) IBOutlet UILabel *balanceLabel;
@property (weak, nonatomic) IBOutlet UILabel *addressLabel;
@property (weak, nonatomic) IBOutlet UILabel *holderLabel;

@end
