//
//  File.h
//  Portnoff
//
//  Created by Yike Xue on 7/13/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "Tax.h"
#import "Balance.h"

@class Tax, Property;

@interface File : NSManagedObject

@property (nonatomic, retain) NSString * fileNumber;
@property (nonatomic, retain) NSString * hoderName;
@property (nonatomic, retain) Property *property;
@property (nonatomic, retain) NSSet *balances;
@property (nonatomic, retain) Tax *taxParcel;
@end

@interface File (CoreDataGeneratedAccessors)

- (void)addBalancesObject:(Balance *)value;
- (void)removeBalancesObject:(Balance *)value;
- (void)addBalances:(NSSet *)values;
- (void)removeBalances:(NSSet *)values;

@end
