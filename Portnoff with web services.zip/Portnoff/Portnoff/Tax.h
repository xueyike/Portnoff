//
//  Tax.h
//  Portnoff
//
//  Created by Yike Xue on 7/13/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class File, Property;

@interface Tax : NSManagedObject

@property (nonatomic, retain) NSString * parcelNumber;
@property (nonatomic, retain) Property *property;
@property (nonatomic, retain) NSSet *files;
@end

@interface Tax (CoreDataGeneratedAccessors)

- (void)addFilesObject:(File *)value;
- (void)removeFilesObject:(File *)value;
- (void)addFiles:(NSSet *)values;
- (void)removeFiles:(NSSet *)values;

@end
