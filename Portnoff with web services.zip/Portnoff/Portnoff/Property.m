//
//  Property.m
//  Portnoff
//
//  Created by Yike Xue on 7/13/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "Property.h"


@implementation Property

@dynamic address;
@dynamic parcel;

@end
