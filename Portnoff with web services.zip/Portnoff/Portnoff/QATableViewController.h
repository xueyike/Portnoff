//
//  QATableViewController.h
//  Portnoff
//
//  Created by Yike Xue on 7/10/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QATableViewController : UITableViewController {
    NSMutableIndexSet *expandedSections;
}

@end
