//
//  ShowBalanceDetailViewController.m
//  Portnoff
//
//  Created by Yike Xue on 7/14/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "ShowBalanceDetailViewController.h"

@interface ShowBalanceDetailViewController ()

@end

@implementation ShowBalanceDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"background.png"]];
    if(_balances == nil || [_balances count] < 1){
        self.balanceLabel.text = [NSString stringWithFormat:@"0"];
    }else{
        for(Balance *b in _balances){
            self.balanceLabel.numberOfLines = 2;
            self.balanceLabel.text = [NSString stringWithFormat:@"$%@ \n   in %@",b.value,b.year];
        }
    }

    self.addressLabel.text = _address;
    self.holderLabel.text = _holderName;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
