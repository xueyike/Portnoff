//
//  QATableViewController.m
//  Portnoff
//
//  Created by Yike Xue on 7/10/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "QATableViewController.h"

@interface QATableViewController ()

@end

@implementation QATableViewController{
    NSMutableArray *QAs;
    int otherExpand;
    int checker;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    otherExpand=100;
    checker=100;
    QAs = [NSMutableArray array];
    NSDictionary *qa1 = [NSDictionary dictionaryWithObjectsAndKeys:@"If I am mailing payment, where should I send my payment?",@"Question",@"If you are paying Souderton Area School District taxes, please send payment to Portnoff Law Associates, Ltd., P.O. Box 326, Norristown, PA 19404 All other payments should be sent to Portnoff Law Associates, Ltd., P.O. Box 3020, Norristown, PA 19404",@"Answer",@"0",@"show", nil];
    [QAs addObject:qa1];
    
    NSDictionary *qa2 = [NSDictionary dictionaryWithObjectsAndKeys:@"If paying by Check or Money Order, to whom should my payment check be written?",@"Question",@"Checks should be made payable to: Portnoff Law Associates, Ltd. in trust for XXX, where XXX is the name of the taxing authority. For example, if you are paying taxes to the Souderton Area School District, you would make the check payable to: Portnoff Law Associates, Ltd. in trust for Souderton Area School District",@"Answer",@"0",@"show", nil];
    [QAs addObject:qa2];
    
    NSDictionary *qa3 = [NSDictionary dictionaryWithObjectsAndKeys:@"Can I make a payment over the phone?",@"Question",@"No. Portnoff Law Associates, Ltd. is unfortunately unable to process payments over the phone but you can pay online. Please visit the payment center.",@"Answer",@"0",@"show", nil];
    [QAs addObject:qa3];
    
    NSDictionary *qa4 = [NSDictionary dictionaryWithObjectsAndKeys:@"Is there a fee for paying online?",@"Question",@"Portnoff Law Associates, Ltd. does not apply a fee for online payments if you are paying via checking account/ACH. You should check with your banking institution in case they charge a fee.\nFor selected municipalities, school districts, and authorities, Portnoff Law Associates, Ltd. offers online payment options for Credit and Debit cards through Official Payments. Official Payments charges a convenience fee for this service that will be an additional charge. Official Payments charges 2.45% of the payment amount, with a minimum fee of $3.95 when using a credit card. A fee of 1% of the payment amount, with a minimum fee of $1.00 is charged when using a debit card. Portnoff Law Associates and the municipalities, school districts, and municipal authorities that they represent do not receive any of these fees.",@"Answer",@"0",@"show", nil];
    [QAs addObject:qa4];
    
    NSDictionary *qa5 = [NSDictionary dictionaryWithObjectsAndKeys:@"Can I set up a payment plan?",@"Question",@"In many cases, yes. Please call Portnoff Law Associates, Ltd. at 866-211-9466 to discus your particular situation.",@"Answer",@"0",@"show", nil];
    [QAs addObject:qa5];
    
    NSDictionary *qa6 = [NSDictionary dictionaryWithObjectsAndKeys:@"If I arrange a payment plan, will I be receiving a monthly bill/statement?",@"Question",@"Portnoff Law Associates, Ltd. does not send out bills or monthly reminders. It is the property owners responsibility to send out monthly payments per plan. There are online resources, such as available to you to set up payment reminders.",@"Answer",@"0",@"show", nil];
    [QAs addObject:qa6];
    
    NSDictionary *qa7 = [NSDictionary dictionaryWithObjectsAndKeys:@"Can you send me a copy of the original bill? When was the original bill mailed?",@"Question",@"Upon request, Portnoff Law Associates, Ltd. will contact our client in an attempt to obtain a copy of the bill or mailing date. Please be advised that in many cases original bills are no longer available.",@"Answer",@"0",@"show", nil];
    [QAs addObject:qa7];
    
    NSDictionary *qa8 = [NSDictionary dictionaryWithObjectsAndKeys:@"What is the difference between Calendar and Fiscal year?",@"Question",@"Calendar year runs from 1/1/XX to 12/31/XX. Fiscal year runs from 7/1/XX to 6/30/X. In most cases the school taxes run on a fiscal year",@"Answer",@"0",@"show", nil];
    [QAs addObject:qa8];
    
    NSDictionary *qa9 = [NSDictionary dictionaryWithObjectsAndKeys:@"Is a claim being collected by Portnoff Law Associates, Ltd. going to affect my credit?",@"Question",@"Portnoff Law Associates, Ltd. does not report to credit agencies. If a lien is filed, it becomes public record. Court documents can be researched when applying for credit.",@"Answer",@"0",@"show", nil];
    [QAs addObject:qa9];
    
    NSDictionary *qa10 = [NSDictionary dictionaryWithObjectsAndKeys:@"Can I see my balance online?",@"Question",@"Portnoff Law Associates, Ltd. provides access for property owners to their unpaid balances online in our claims database located at the Balanice Inquiry link on this page.",@"Answer",@"0",@"show", nil];
    [QAs addObject:qa10];
    
    NSDictionary *qa11 = [NSDictionary dictionaryWithObjectsAndKeys:@"Where is my Portnoff Law Associates, Ltd. file number located?",@"Question",@"Your file number is typically found on the bottom left hand corner of correspondence and begins with two digits and then followed by five digits. There may be additional digits or dashes beyond that, but your file number is the beginning seven digits. (i.e. XX-XXXXX)",@"Answer",@"0",@"show", nil];
    [QAs addObject:qa11];
    
    NSDictionary *qa12 = [NSDictionary dictionaryWithObjectsAndKeys:@"Can I make an in person payment?",@"Question",@"Portnoff Law Associates, Ltd. can accept payments in the form of check, money order, or cash, during business hours. Portnoff Law Associates, Ltd. is located at 1000 Sandy HIll Rd, Ste. 150, Norristown, PA 19401.",@"Answer",@"0",@"show", nil];
    [QAs addObject:qa12];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
    return [QAs count];
}

-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(otherExpand==section)
        return 1;
    
    return  0;
    
}

-(BOOL)tableView:(UITableView *)table canCollapse:(NSIndexPath *)indexPath
{
    return NO;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *Identifier=@"Cell";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:Identifier];
    if (cell==nil)
    {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:Identifier];
        
    }

    cell.textLabel.text=[QAs[indexPath.section] objectForKey:@"Answer"];
    cell.textLabel.numberOfLines = 30;
    cell.backgroundColor = [UIColor colorWithRed:203 green:207 blue:191 alpha:0];

    [tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLineEtched];
    [tableView setSeparatorColor:[UIColor purpleColor]];
    
    return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    // Column width
    CGFloat contentWidth = self.tableView.frame.size.width;
    
    UIFont *font = [UIFont systemFontOfSize:20];

    NSString *content = [QAs[indexPath.section] objectForKey:@"Answer"];
    // calculate the necessary minimum height
    CGSize size = [content sizeWithFont:font constrainedToSize:CGSizeMake(contentWidth, 1000) lineBreakMode:UILineBreakModeWordWrap];
    return size.height+20;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    
    UIView *view1=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 100)];
    [view1.layer setCornerRadius:20];
    view1.layer.borderWidth=2;
    view1.layer.borderColor=[UIColor brownColor].CGColor;
    UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(15, 0, 300, 90)];
    label.backgroundColor=[UIColor clearColor];
    
    label.text=[QAs[section] objectForKey:@"Question"];
    label.numberOfLines = 3;
    label.textColor = [UIColor colorWithRed:107 green:0 blue:0 alpha:0];
    UIButton *btn=[UIButton buttonWithType:UIButtonTypeDetailDisclosure];
    btn.frame=CGRectMake(300, 15, 70, 70);
    btn.backgroundColor=[UIColor clearColor];
    btn.tag=section;
    
    view1.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"background.png"]];
    label.textColor=[UIColor blackColor];
    label.font=[UIFont fontWithName:@"American TypeWriter" size:18];
    [view1 addSubview:btn];
    [view1 addSubview:label];
    
    [btn addTarget:self action:@selector(Btntap:) forControlEvents:UIControlEventTouchUpInside];
    
    return view1;
}


-(void)Btntap : (UIButton *)btn
{
    if(otherExpand!=100)
    {
        if (otherExpand==btn.tag)
        {
            NSMutableArray *tempArr2=[[NSMutableArray alloc]init];
            
            NSIndexPath *indexx1=[NSIndexPath indexPathForRow:0 inSection:otherExpand];
            [tempArr2 addObject:indexx1];
            checker=0;
            otherExpand=100;
            [self.tableView deleteRowsAtIndexPaths:tempArr2 withRowAnimation:UITableViewRowAnimationAutomatic];
        }
        
        else
        {
            NSMutableArray *tempArr2=[[NSMutableArray alloc]init];
            NSIndexPath *indexx1=[NSIndexPath indexPathForRow:0 inSection:otherExpand];
            [tempArr2 addObject:indexx1];
            checker=1;
            otherExpand=100;
            [self.tableView deleteRowsAtIndexPaths:tempArr2 withRowAnimation:UITableViewRowAnimationAutomatic];
        }
    }
    
    if(checker!=0)
    {
        otherExpand=btn.tag;
        //checker=
        NSMutableArray *tempArr=[[NSMutableArray alloc]init];
        NSIndexPath *indexx=[NSIndexPath indexPathForRow:0 inSection:btn.tag];
        [tempArr addObject:indexx];
        [self.tableView insertRowsAtIndexPaths:tempArr withRowAnimation:UITableViewRowAnimationAutomatic];
        
        checker=1;
    }
    checker=100;
}



-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 100;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
