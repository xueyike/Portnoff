//
//  File.m
//  Portnoff
//
//  Created by Yike Xue on 7/13/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "File.h"
#import "Property.h"


@implementation File

@dynamic fileNumber;
@dynamic hoderName;
@dynamic property;
@dynamic balances;
@dynamic taxParcel;

@end
