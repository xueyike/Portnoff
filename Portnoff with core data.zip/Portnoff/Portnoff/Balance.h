//
//  Balance.h
//  Portnoff
//
//  Created by Yike Xue on 7/13/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class File;

@interface Balance : NSManagedObject

@property (nonatomic, retain) NSString * year;
@property (nonatomic, retain) NSNumber * value;
@property (nonatomic, retain) NSSet *property;
@end

@interface Balance (CoreDataGeneratedAccessors)

- (void)addPropertyObject:(File *)value;
- (void)removePropertyObject:(File *)value;
- (void)addProperty:(NSSet *)values;
- (void)removeProperty:(NSSet *)values;

@end
