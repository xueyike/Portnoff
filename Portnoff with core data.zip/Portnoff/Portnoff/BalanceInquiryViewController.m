//
//  BalanceInquiryViewController.m
//  Portnoff
//
//  Created by Yike Xue on 7/13/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "BalanceInquiryViewController.h"
#import "ShowBalanceDetailViewController.h"
#import "AppDelegate.h"
#import "Tax.h"
#import "File.h"
#import "Property.h"

@interface BalanceInquiryViewController (){
    CaptchaView *_captchaView;
    NSSet *balSet;
    NSString *addr;
    NSString *holder;
    NSManagedObjectContext* managedObjectContext;
    NSFetchedResultsController *fetchedResultsController;
}

@end

@implementation BalanceInquiryViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    _captchaView = [[CaptchaView alloc] initWithFrame:CGRectMake(0, 0, 150, 40)];
    self.parcelNumber.delegate = self;
    self.fileNumber.delegate = self;
    self.captchaInput.delegate = self;
    [self.captcha addSubview:_captchaView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

//In order to prevent the keyboard blocking the input boxes
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self animateTextField: textField up: YES];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self animateTextField: textField up: NO];
}
//move the view up
- (void) animateTextField: (UITextField *) textField up: (BOOL) up
{
    //move up 0.3*view.height
    const int movementDistance = self.view.frame.size.height*0.3; // tweak as needed

    int movement = (up ? -movementDistance : movementDistance);

    [UIView beginAnimations: @"Animation" context: nil];

    [UIView setAnimationBeginsFromCurrentState: YES];

    [UIView setAnimationDuration: 0.20];

    if(self.view.frame.origin.y <= 0){
        self.view.frame = CGRectOffset(self.view.frame, 0, movement);
        
        [UIView commitAnimations];
    }
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (IBAction)pressedSearch:(id)sender {
    if ([self.captchaInput.text isEqualToString:_captchaView.changeString]) {

        AppDelegate *appDelegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
        managedObjectContext = appDelegate.managedObjectContext;
        
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription
                                       entityForName:@"Tax" inManagedObjectContext:managedObjectContext];
        [fetchRequest setEntity:entity];
        NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"parcelNumber"ascending:YES];
        [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];

        NSPredicate * predicate;
        predicate = [NSPredicate predicateWithFormat:@"parcelNumber == %@", self.parcelNumber.text];
        [fetchRequest setPredicate: predicate];
        [fetchRequest setFetchLimit:1];
        
        NSError *error;
        NSArray *fetchedObjects = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        if (error) {
            NSLog(@"Error : %@\n", [error localizedDescription]);
        }
        
        if(fetchedObjects == nil || [fetchedObjects count] < 1){
            UIAlertView *alview = [[UIAlertView alloc] initWithTitle:@"No searching result!" message:@"The parcel number is invalid! Please try again." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alview show];
        }else{
            Tax *result = [fetchedObjects objectAtIndex:0];
            addr = result.property.address;
            NSFetchRequest *fetchRequest2 = [[NSFetchRequest alloc] init];
            NSEntityDescription *entity2 = [NSEntityDescription
                                           entityForName:@"File" inManagedObjectContext:managedObjectContext];
            [fetchRequest2 setEntity:entity2];
            NSError *error2;
            NSPredicate * predicate2;
            predicate2 = [NSPredicate predicateWithFormat:@"fileNumber == %@", self.fileNumber.text];
            [fetchRequest2 setPredicate: predicate2];
            
            NSArray *fetchedObjects2 = [managedObjectContext executeFetchRequest:fetchRequest2 error:&error2];
            
            if(fetchedObjects2 == nil || [fetchedObjects2 count] < 1){
                UIAlertView *alview = [[UIAlertView alloc] initWithTitle:@"No searching result!" message:@"The file number is invalid! Please try again." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                [alview show];
            }else{
                File *result2 = fetchedObjects2[0];
                holder = result2.hoderName;
                NSSet *bals = result2.balances;
//                NSFetchRequest *fetchRequest3 = [[NSFetchRequest alloc] init];
//                NSEntityDescription *entity3 = [NSEntityDescription
//                                                entityForName:@"Balance" inManagedObjectContext:managedObjectContext];
//                [fetchRequest3 setEntity:entity3];
//                NSError *error3;
//                NSPredicate * predicate3;
//                predicate3 = [NSPredicate predicateWithFormat:@"ANY property.parcel == %@", self.parcelNumber.text];
//                [fetchRequest3 setPredicate: predicate3];
//                
//                NSArray *fetchedObjects3 = [managedObjectContext executeFetchRequest:fetchRequest3 error:&error3];
//                
//                if(fetchedObjects3 != nil && [fetchedObjects2 count] > 0){
//                    Balance *result3 = fetchedObjects3[0];
//                    bal = result3.value;
                balSet = bals;
                [self.parcelNumber resignFirstResponder];
                [self.fileNumber resignFirstResponder];
                [self.captchaInput resignFirstResponder];
                [_captchaView changeCaptcha];
                [_captchaView setNeedsDisplay];
                [self performSegueWithIdentifier:@"showDetail" sender:self];
            }
        }
    }
    else
    {
        CAKeyframeAnimation *anim = [CAKeyframeAnimation animationWithKeyPath:@"transform.translation.x"];
        anim.repeatCount = 1;
        anim.values = @[@-20, @20, @-20];
        [_captchaView.layer addAnimation:anim forKey:nil];
        UIAlertView *alview = [[UIAlertView alloc] initWithTitle:@"Wrong Captcha!" message:@"The captcha is invalid! Please try again." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alview show];
        [_captchaView changeCaptcha];
        [_captchaView setNeedsDisplay];
        self.captchaInput.text = @"";
    }
}

- (IBAction)didEndOnExit:(id)sender {
    [self resignFirstResponder];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    //Get the new view controller using [segue destinationViewController].
    //Pass the selected object to the new view controller.
    if([segue.identifier isEqualToString:@"showDetail"]){
        ShowBalanceDetailViewController *destination = segue.destinationViewController;
        if ([destination respondsToSelector:@selector(setDelegate:)]) {
            [destination setValue:self forKey:@"delegate"];
        }
        if ([destination respondsToSelector:@selector(setAddress:)]) {
            
            [destination setValue:addr forKey:@"address"];
        }
        if ([destination respondsToSelector:@selector(setHolderName:)]) {
            
            [destination setValue:holder forKey:@"holderName"];
        }
        if ([destination respondsToSelector:@selector(setBalances:)]) {
            
            [destination setValue:balSet forKey:@"balances"];
        }
    }
}

@end
