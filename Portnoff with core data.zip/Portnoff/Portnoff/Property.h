//
//  Property.h
//  Portnoff
//
//  Created by Yike Xue on 7/13/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "Tax.h"

@class Tax;

@interface Property : NSManagedObject

@property (nonatomic, retain) NSString * address;
@property (nonatomic, retain) Tax *parcel;

@end
