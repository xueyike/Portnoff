//
//  OtherPaymentViewController.h
//  Portnoff
//
//  Created by Yike Xue on 7/10/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OtherPaymentViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIWebView *webview;

@end
