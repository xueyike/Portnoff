//
//  CaptchaView.h
//  Portnoff
//
//  Created by Yike Xue on 7/13/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CaptchaView : UIView
@property (nonatomic, retain) NSArray *changeArray; //characters
@property (nonatomic, retain) NSMutableString *changeString; //string

-(void)changeCaptcha;
@end
