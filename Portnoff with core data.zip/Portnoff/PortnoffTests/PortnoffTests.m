//
//  PortnoffTests.m
//  PortnoffTests
//
//  Created by Yike Xue on 7/9/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <XCTest/XCTest.h>
#import "AppDelegate.h"
#import "Tax.h"
#import "Balance.h"
#import "File.h"
#import "Property.h"

@interface PortnoffTests : XCTestCase
@property (nonatomic,strong) NSManagedObjectContext* managedObjectContext;
@property (nonatomic, retain) NSFetchedResultsController *fetchedResultsController;
@end

@implementation PortnoffTests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
    AppDelegate *appDelegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    _managedObjectContext = appDelegate.managedObjectContext;
    
//    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    Balance *balance1 = [NSEntityDescription
                         insertNewObjectForEntityForName:@"Balance"
                         inManagedObjectContext:_managedObjectContext];
    balance1.year = @"2014";
    balance1.value = [NSNumber numberWithInt:5555];
    
    File *file1 = [NSEntityDescription
                      insertNewObjectForEntityForName:@"File"
                      inManagedObjectContext:_managedObjectContext];
    file1.fileNumber = @"yy-xxxx-0";
    [file1 addBalancesObject:balance1];
    file1.hoderName = @"Mary Su";
    
    Tax *tax1 = [NSEntityDescription
                 insertNewObjectForEntityForName:@"Tax"
                 inManagedObjectContext:_managedObjectContext];
    tax1.parcelNumber = @"qwertyuiop";
    [tax1 addFilesObject:file1];
    file1.taxParcel = tax1;
    
    Property *property1 = [NSEntityDescription
                         insertNewObjectForEntityForName:@"Property"
                         inManagedObjectContext:_managedObjectContext];
    property1.parcel = tax1;
    property1.address = @"888 Main Street, PA";
    file1.property = property1;
    tax1.property = property1;
    
    NSError *error;
//    NSArray *fetchedObjects = [NSManagedObjectContext executeFetchRequest:fetchRequest error:&error];
    if (![_managedObjectContext save:&error]) {
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }
    NSLog(@"Testing set up");
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    XCTAssert(YES, @"Pass");
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
